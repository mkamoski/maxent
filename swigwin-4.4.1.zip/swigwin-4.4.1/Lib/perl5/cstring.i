%include <typemaps/cstring.swg>
